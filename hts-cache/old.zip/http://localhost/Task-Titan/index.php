
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Task Titan</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.1/css/bulma.min.css">
    <link rel="stylesheet" href="vendors/css/modal-fx.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/config.css">
</head>

<body>
    <header>
        <nav class="navbar" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <a class="navbar-item" href="index.php">
                    <img src="img/logo.svg" alt="logo task-titan">
                </a>
            </div>

            <div id="navbarBasicExample" class="navbar-menu">
                <div class="navbar-start">
                    <a class="navbar-item" href="index.php">Inicio</a>
                    <a class="navbar-item" href="#">Características</a>
                    <a class="navbar-item" href="#">Precios</a>
                    <a class="navbar-item" href="#">Blog</a>
                    <a class="navbar-item" href="#">Contacto</a>
                </div>

                <div class="navbar-end">
                                            <a class="navbar-item modal-button" data-target="modalInicio" aria-haspopup="true">Iniciar
                            sesión</a>
                        <a class="navbar-item modal-button" data-target="modalRegistro" aria-haspopup="true">Registrarse</a>
                                    </div>
            </div>
        </nav>

    </header>

    <!-- Notificaciones -->
    <div id="notifications"
        style="position: fixed; top: 0; right: 0; left: 0; z-index: 1000; margin: 0 auto; text-align: center; width: 100%;">
    </div>

    <main>
        <!-- Contenido principal -->
        <section class="section">
            <div class="container has-text-centered">
                <h1 class="title">
                    Revoluciona tu forma de trabajar con <strong class="has-text-primary">Task Titan</strong>
                </h1>
                <p class="subtitle mt-6">
                    Descubre cómo <strong class="has-text-primary">Task Titan</strong> puede transformar tu
                    productividad y eficiencia en cualquier proyecto. Únete a esta experiencia innovadora, que adopta un
                    sistema de organización con la finalidad de alcanzar tus metas.
                </p>
                <a href="#" class="button is-primary modal-button is-medium mt-4" data-target="modalInicio"
                    aria-haspopup="true">Comienza ahora</a>
            </div>
        </section>

        <!-- Sección de características -->
        <section class="section">
            <div class="container">
                <div class="columns">
                    <div class="column">
                        <div class="card">
                            <div class="card-image">
                                <figure class="image is-4by3">
                                    <img src="img/tareas.jpg" alt="gestion de tareas">
                                </figure>
                            </div>
                            <div class="card-content">
                                <h3 class="title is-4 mb-4">Gestión de tareas</h3>
                                <p class="subtitle is-6">Crea y asigna tareas fácilmente, establece plazos y prioridades
                                    claras acorde a tus necesidades, fija metas específicas y asegura que cada tarea se
                                    realice a tiempo en el plazo estipulado para garantizar el éxito.</p>
                            </div>
                        </div>
                    </div>

                    <div class="column">
                        <div class="card">
                            <div class="card-image">
                                <figure class="image is-4by3">
                                    <img src="img/team.jpg" alt="colaboracion de equipos">
                                </figure>
                            </div>
                            <div class="card-content">
                                <h3 class="title is-4 mb-4">Colaboración en equipo</h3>
                                <p class="subtitle is-6">Trabaja en sintonía con tu equipo, comparte archivos, comenta
                                    tareas manteniendo una comunicación fluida y fomenta un ambiente de trabajo
                                    colaborativo donde cada miembro se sienta valorado.</p>
                            </div>
                        </div>
                    </div>

                    <div class="column">
                        <div class="card">
                            <div class="card-image">
                                <figure class="image is-4by3">
                                    <img src="img/seguimiento.jpg" alt="seguimiento de tareas">
                                </figure>
                            </div>
                            <div class="card-content">
                                <h3 class="title is-4 mb-4">Seguimiento del progreso</h3>
                                <p class="subtitle is-6">Monitorea el avance de tus proyectos con precisión, obtén
                                    informes detallados y análisis exhaustivos asegurándote de que cada proyecto se
                                    desarrolle según lo planeado.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Pie de página -->
    <footer class="footer">
        <div class="content has-text-centered">
            <p>© 2024 Task Titan. Todos los derechos reservados.</p>
        </div>
    </footer>

    <!-- Modal de Registro -->
    <div id="modalRegistro" class="modal modal-fx-slideTop">
        <div class="modal-background"></div>
        <div class="modal-card">
            <header class="modal-card-head">
                <p class="modal-card-title">Registrarse</p>
                <button class="delete" aria-label="close"></button>
            </header>
            <section class="modal-card-body">
                <form id="registroForm" action="php/auth/registro.php" method="post">
                    <input type="hidden" name="dato" value="insertar">
                    <div class="field">
                        <label class="label" for="nombre">Nombre</label>
                        <div class="control">
                            <input class="input" type="text" id="nombre" name="nombre" placeholder="Ingrese su nombre">
                        </div>
                    </div>

                    <div class="field">
                        <label class="label" for="usuario">Usuario</label>
                        <div class="control">
                            <input class="input" type="text" id="usuario" name="usuario"
                                placeholder="Ingrese su usuario">
                        </div>
                    </div>

                    <div class="field">
                        <label class="label" for="email">Correo electrónico</label>
                        <div class="control">
                            <input class="input" type="email" id="email" name="email"
                                placeholder="Ingrese su correo electrónico">
                        </div>
                    </div>

                    <div class="field">
                        <label class="label" for="password">Contraseña</label>
                        <div class="control">
                            <input class="input" type="password" id="password" name="password"
                                placeholder="Ingrese su contraseña">
                        </div>
                    </div>

                    <div class="field">
                        <label class="label" for="confirm_password">Confirmar contraseña</label>
                        <div class="control">
                            <input class="input" type="password" id="confirm_password" name="confirm_password"
                                placeholder="Repita su contraseña">
                        </div>
                    </div>
                    <footer class="modal-card-foot">
                        <button type="submit" name="registro" id="submit" value="Registrarse"
                            class="button is-primary">Registrarse</button>
                        <button type="button" class="button cancel">Cancelar</button>
                    </footer>
                </form>
            </section>
        </div>
    </div>

    <!-- Modal de Inicio de Sesión -->
    <div id="modalInicio" class="modal modal-fx-slideTop">
        <div class="modal-background"></div>
        <div class="modal-card">
            <header class="modal-card-head">
                <p class="modal-card-title">Iniciar sesión</p>
                <button class="delete" aria-label="close"></button>
            </header>
            <section class="modal-card-body">
                <form id="loginForm" action="php/auth/login.php" method="post">
                    <div class="field">
                        <label class="label" for="email">Correo electrónico</label>
                        <div class="control">
                            <input class="input" type="email" id="email" name="email"
                                placeholder="Ingrese su correo electrónico">
                        </div>
                    </div>

                    <div class="field">
                        <label class="label" for="pass">Contraseña</label>
                        <div class="control">
                            <input class="input" type="password" id="pass" name="password"
                                placeholder="Ingrese su contraseña">
                        </div>
                    </div>
                    <footer class="modal-card-foot">
                        <button type="submit" name="login" id="login" value="Iniciar sesión"
                            class="button is-primary">Iniciar sesión</button>
                        <button class="button cancel">Cancelar</button>
                        <a href="#" id="forgotPassword" class="button is-text">Olvidé mi contraseña</a>
                    </footer>
                </form>
            </section>
        </div>
    </div>

    <!-- Modal de Restablecimiento de Contraseña -->
    <div id="modalForgotPassword" class="modal modal-fx-slideTop">
        <div class="modal-background"></div>
        <div class="modal-card">
            <header class="modal-card-head">
                <p class="modal-card-title">Restablecer contraseña</p>
                <button class="delete" aria-label="close"></button>
            </header>
            <section class="modal-card-body">
                <form id="forgotPasswordForm">
                    <div class="field">
                        <label class="label" for="forgotEmail">Correo electrónico</label>
                        <div class="control">
                            <input class="input" type="email" id="forgotEmail" name="email"
                                placeholder="Ingrese su correo electrónico" required>
                        </div>
                    </div>
                    <footer class="modal-card-foot">
                        <button type="submit" class="button is-primary">Enviar enlace</button>
                        <button type="button" class="button cancel">Cancelar</button>
                    </footer>
                </form>
            </section>
        </div>
    </div>

    <script src="js/script.js"></script>
</body>

</html>